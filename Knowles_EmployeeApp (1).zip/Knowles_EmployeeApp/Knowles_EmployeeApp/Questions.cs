﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Knowles_EmployeeApp
{
    internal class Questions
    {
//Employee Method
        public string EmployeeName(string name)
        {
            Console.Write("Please enter the employee's " + name + " name:\t\t\t");
            return Console.ReadLine();
        }

        public double EmployeeTotalSales()
        {
            double totalSales;

            Console.Write("Please enter the employee's total sales for the month:\t");
            totalSales = double.Parse(Console.ReadLine());

            return totalSales;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Knowles_EmployeeApp
{
    internal class Knowles_EmployeeApp
    {
        static void Main(string[] args)
        {//Variables
            string firstName;
            string lastName;
            double sales;

            Employee employee;
            Questions q = new Questions();
            Info info = new Info();

            info.DisplayInfo("Employee App");

            firstName = q.EmployeeName("first");
            lastName = q.EmployeeName("last");
            sales = q.EmployeeTotalSales();

            employee = new Employee(firstName, lastName, sales);
            employee.CalculateWithholdings();

            WriteLine("\n\n\n\nName: " + employee.Name);
            WriteLine();
            WriteLine("{0,-35}{1:C2}", "Employee Gross Income:", employee.CalculateCommissionIncome());
            WriteLine("{0,-35}{1:C2}", "Federal Tax Withheld:", employee.Federal);
            WriteLine("{0,-35}{1:C2}", "Social Security Tax Withheld:", employee.SS);
            WriteLine("{0,-35}{1:C2}", "Retirement Contributions:", employee.Retirement);
            WriteLine();
            WriteLine("{0,-35}{1:C2}", "Employee Net Pay:", employee.CalculateCommissionIncome() - employee.Federal - employee.SS - employee.Retirement);
            ReadKey();


        }
    }
}

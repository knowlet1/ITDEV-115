﻿using System;
using static System.Console;

namespace Knowles_RectangleApp
{
    internal class Knowles_RectangleApp
    {
        static void Main(string[] args)
        {
            Dimensions dimensions = new Dimensions();

            AssignmentInfo();
            Directions();

            dimensions.InputHeight();
            dimensions.InputWidth();


            WriteLine("\nThe area of the rectangle is {0:f1}", dimensions.CalculateArea());
            WriteLine("The perimeter of the rectangle is {0:f1}", dimensions.CalculatePerimeter());

            ReadKey();
        }
        static void Directions()
        {
            WriteLine("\nThis program will calculate the area and the perimeter of a rectangle.");
            WriteLine("All you need to do is enter the rectangle's height and width.\n");
        }

        static void AssignmentInfo()
        {

            WriteLine("***********************************************************************");
            WriteLine();
            WriteLine("Name:\t\tTrevor Knowles");
            WriteLine("\nCourse:\t\tITDEV-115");
            WriteLine("\nInstructor:\tJanese Christie");
            WriteLine("\nAssignment:\tRectangle App");
            WriteLine("\nDate:\t\t" + DateTime.Today.ToShortDateString());
            WriteLine();
            WriteLine("***********************************************************************");

        }

    }
}
